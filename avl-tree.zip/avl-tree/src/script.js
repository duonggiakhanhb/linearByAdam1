/*************   variables   *************/
var add = document.getElementById('add');
var search = document.getElementById('search');
var input = document.getElementById('input');
var root = null;
var time = 1000;
var rootTopPosition = 80;
let search_interval;
const SEARCH_INTERVAL_TIME=800;


document.onkeypress=function(e){
    // console.log(e.keyCode, e.charCode);
    if(e.keyCode==13||e.charCode==105||e.charCode==73)
    {
        Add();
        input.value="";
    }
    else if(e.charCode==115||e.charCode==83)
    {
        callSearch();

        input.value="";
    }
    else if(e.charCode==100||e.charCode==68)
    {
        callDelete();
        input.value="";
    }
}
add.onclick = function(){
    Add();
}
search.onclick = function(){
    callSearch();
}
Deletee.onclick = function(){
    callDelete();
}

function callSearch(){
    if(input.value == ""){
        alert("You must enter a value.");
        return;
    }
    Search(parseInt(input.value),root);
    setTimeout(function(){
        mainColor(root);
    },3*time);
}
function callDelete(){
    if(input.value == ""){
        alert("You must enter a value.");
        return;
    }
    root=Delete(parseInt(input.value),root);
    setTimeout(function(){
      mainColor(root);
      Reallocate(root,window.innerWidth/2, rootTopPosition);
      var temp=mostLeft(root);
      if(parseInt(temp.node.left)<0){
          setPosition(root,-1*parseInt(temp.node.left));
      }
    }, time);
}
function Add(){
    if(input.value == ""){
        alert("You must enter a value.");
        return;
    }
    // mainColor(root);
    if(!root){
        root = new Node(parseInt(input.value), window.innerWidth/2, rootTopPosition);
        return;
    }
    else{
        root= insert(parseInt(input.value), root , root.node.left, root.node.top);
    }
    setTimeout(function(){
        Reallocate(root,window.innerWidth/2, rootTopPosition);
        var temp=mostLeft(root);
        if(parseInt(temp.node.left)<0){
            setPosition(root,-1*parseInt(temp.node.left));
        }
        mainColor(root);
    }, time);
}


function insert(val, node , x , y) {
    if(!node) {
        return new Node(val, x, y);
    }
    if (val<node.n.innerHTML) {
        node.node.backgroundColor = "yellow";
        node.left=insert(val, node.left, parseInt(node.node.left)-50 , parseInt(node.node.top)+50);
        // node.node.backgroundColor = "red";
    }
    else if (val>node.n.innerHTML) {
        node.node.backgroundColor = "yellow";
        node.right = insert(val, node.right, parseInt(node.node.left)+50 , parseInt(node.node.top)+50);
        // node.node.backgroundColor = "red";
    }
    else{
        // node.node.backgroundColor = "red";
        return node;
    }
    node.h=1+Math.max(Height(node.left),Height(node.right));

    var balance = GetBalance(node);

    // left left rotation
    if(balance>1 && val < node.left.n.innerHTML){
        node=rotateToRight(node);
        return node;
    }

    // right right rotation
    else if (balance < -1 && val > node.right.n.innerHTML){
        node=rotateToLeft(node);
        return node;
    }

    if (balance > 1 && val > node.left.n.innerHTML)
    {
        node.left =  rotateToLeft(node.left);
        node=rotateToRight(node);
        return node;
    }

    // Right Left Case
    if (balance < -1 && val < node.right.n.innerHTML)
    {
        node.right = rotateToRight(node.right);
        node=rotateToLeft(node);
        return node;
    }
    return node;
}

function Height(node) {
    if(!node){
        return -1;
    }
    return node.h;
}

function GetBalance(node){
    if (!node){
        return 0;
    }
    return Height(node.left) - Height(node.right);
}

function rotateToRight(node) {
    var n = node.left;
    var nr= n.right;
    n.right=node;
    node.left=nr;
    node.h = 1+Math.max(Height(node.left), Height(node.right));
    n.h = 1+Math.max(Height(n.left), Height(n.right));
    return n;
}

function rotateToLeft(node) {
    var newP = node.right;
    var temp = newP.left;
    newP.left = node;
    node.right = temp;
    node.h = 1+Math.max(Height(node.left), Height(node.right));
    newP.h = 1+Math.max(Height(newP.left), Height(newP.right));
    return newP;
}

function Reallocate(node, x, y){
    if(!node)
        return;
    var temp = ( Math.pow(2, node.h-1) ) * 50;

    if(node.linel){
        document.body.removeChild(node.linel);
        node.linel = null;
    }
    if(node.liner){
        document.body.removeChild(node.liner);
        node.liner = null;
    }

    if(node.left){
        node.linel = getLine(x, y, x-temp, y+100 , 1);
    }
    if(node.right){
        node.liner = getLine(x, y, x+temp, y+100, -1);
    }

    node.node.left= x+'px';
    node.node.top=y+'px';
    // node.node.backgroundColor = "red";
    Reallocate(node.left,x-temp,y+100);
    Reallocate(node.right,x+temp,y+100);
}

function mostLeft(node){
    var cur=node;
    while(cur.left)
    {
        cur=cur.left;
    }
    return cur;
}

function setPosition(node,shifting) {
    if(!node)
    {
        return;
    }
    setPosition(node.left , shifting);
    setPosition(node.right , shifting);
    node.node.left = parseInt(node.node.left) + shifting +'px';
    if(node.linel){
        node.linel.style.left = parseInt(node.linel.style.left) + shifting +'px';
    }
    if(node.liner){
        node.liner.style.left = parseInt(node.liner.style.left) + shifting +'px';
    }
}

function Search(val, node) {
  search_interval=setTimeout( () => {
      if(!node){
          alert("Not found :V");
          clearInterval(search_interval);
          return;
      }
      else if(node.n.innerHTML==val){
          node.node.backgroundColor = "green";
          return;
      }
      else if(node.n.innerHTML<val){
          node.node.backgroundColor = "yellow";
          Search(val,node.right);
          // node.node.backgroundColor = "red";
      }
      else if(node.n.innerHTML>val){
          node.node.backgroundColor = "yellow";
          Search(val,node.left);
          // node.node.backgroundColor = "red";
      }
  }, SEARCH_INTERVAL_TIME)
}

function Delete(val , node){
    if(!node)
    {
        return node;
    }
    node.node.backgroundColor = "yellow";
    if(val<node.n.innerHTML)
    {
        node.left=Delete(val,node.left);
    }
    else if(val>node.n.innerHTML)
    {
        node.right=Delete(val,node.right);
    }
    else if(val == node.n.innerHTML)
    {
        if(!node.left)
        {
            var temp=node;
            node= node.right;
            document.body.removeChild(temp.n);
            if(node){
                document.body.removeChild(temp.liner);
            }
            console.log(delete temp);
            temp=null;
            return node;
        }
        else if(!node.right)
        {
            var temp=node;
            node=node.left;
            document.body.removeChild(temp.n);
            document.body.removeChild(temp.linel);
            temp=null;
            console.log(delete temp);
            return node;
        }
        else
        {
            var temp= mostLeft(node.right);
            node.n.innerHTML=temp.n.innerHTML;
            node.right = Delete(parseInt(temp.n.innerHTML),node.right);
        }
    }
    node.h=1+Math.max(Height(node.left),Height(node.right));

    var balance = GetBalance(node);



    // Left Left Case
    if (balance > 1 && GetBalance(node.left) >= 0)
    {
        node=rotateToRight(node);
        return node;
    }


    // Right Right Case
    if (balance < -1 && GetBalance(node.right) <= 0)
    {
        node=rotateToLeft(node);
        return node;
    }

    // Left Right Case
    if (balance > 1 && GetBalance(node.left) < 0)
    {
        node.left =  rotateToLeft(node.left);
        node=rotateToRight(node);
        return node;
    }

    // Right Left Case
    if (balance < -1 && GetBalance(node.right) > 0)
    {
        node.right = rotateToRight(node.right);
        node=rotateToLeft(node);
        return node;
    }
    return node;
}

function Node(val, x, y) {
    this.left= null;
    this.right= null;
    this.h=0;
    this.n = document.createElement('div');
    this.n.innerHTML = val;
    this.n.className = "node";
    this.node = this.n.style;
    this.node.top = y + 'px';
    this.node.left = x +'px';
    this.linel = null;
    this.liner = null;
    document.body.appendChild(this.n);
    return this;
}

function sleep(ms){
    var curT=new Date().getTime();
    var duration=curT+ms;
    while(curT<duration)
    {
        curT= new Date().getTime();
    }
}

function getLength(x1, y1, x2, y2){
    var x = Math.pow(y1-y2,2);
    var y = Math.pow(x1-x2,2);
    return Math.sqrt(x+y);
}

function getAngle(x1, x2, dist){
    var a = Math.abs(x1 - x2);
    return Math.asin(a/dist);
}

function getLine(x1,y1,x2,y2,fact){
    var line = document.createElement('div');
    line.className = "line";
    line.style.top = y1 + 25 + 'px';
    line.style.left = x1 + 25 + 'px';
    var length = getLength(x1, y1, x2, y2);
    line.style.height = length + 'px';
    line.style.transform = "rotate(" + fact*getAngle(x1, x2, length) + "rad)";
    document.body.appendChild(line);
    return line;
}

function mainColor(node){
    if(!node)
        return;
    node.node.backgroundColor = "red";
    mainColor(node.left);
    mainColor(node.right);
}